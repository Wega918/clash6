-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Дек 17 2025 г., 15:44
-- Версия сервера: 8.0.34-26-beget-1-1
-- Версия PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `nikand991_clash`
--

-- --------------------------------------------------------

--
-- Структура таблицы `clans`
--
-- Создание: Дек 10 2025 г., 17:13
--

DROP TABLE IF EXISTS `clans`;
CREATE TABLE `clans` (
  `id` int UNSIGNED NOT NULL,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `type` enum('open','invite','closed') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `required_trophies` int NOT NULL DEFAULT '0',
  `level` int NOT NULL DEFAULT '1',
  `points` int NOT NULL DEFAULT '0',
  `leader_id` int UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `clan_members`
--
-- Создание: Дек 10 2025 г., 17:13
--

DROP TABLE IF EXISTS `clan_members`;
CREATE TABLE `clan_members` (
  `id` int UNSIGNED NOT NULL,
  `clan_id` int UNSIGNED NOT NULL,
  `user_id` int UNSIGNED NOT NULL,
  `role` enum('leader','elder','member') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'member',
  `joined_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `player_army`
--
-- Создание: Дек 10 2025 г., 17:13
--

DROP TABLE IF EXISTS `player_army`;
CREATE TABLE `player_army` (
  `id` int UNSIGNED NOT NULL,
  `user_id` int UNSIGNED NOT NULL,
  `unit_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ID юнита (напр. barbarian)',
  `amount` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `player_buildings`
--
-- Создание: Дек 10 2025 г., 17:13
-- Последнее обновление: Дек 10 2025 г., 17:13
--

DROP TABLE IF EXISTS `player_buildings`;
CREATE TABLE `player_buildings` (
  `id` int UNSIGNED NOT NULL,
  `user_id` int UNSIGNED NOT NULL,
  `building_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ID из game_data (напр. townhall, cannon)',
  `level` int NOT NULL DEFAULT '1',
  `x` int NOT NULL DEFAULT '0',
  `y` int NOT NULL DEFAULT '0',
  `status` enum('active','upgrading','constructing') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `finish_time` int DEFAULT NULL COMMENT 'Unix timestamp завершения стройки',
  `stored_resource` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `player_buildings`
--

INSERT INTO `player_buildings` (`id`, `user_id`, `building_id`, `level`, `x`, `y`, `status`, `finish_time`, `stored_resource`) VALUES
(1, 2, 'townhall', 3, 22, 22, 'active', NULL, 0),
(2, 2, 'gold_mine', 1, 18, 26, 'active', NULL, 0),
(3, 2, 'elixir_collector', 1, 26, 26, 'active', NULL, 0),
(4, 2, 'gold_storage', 1, 18, 18, 'active', NULL, 0),
(5, 2, 'elixir_storage', 1, 26, 18, 'active', NULL, 0),
(6, 2, 'barracks', 1, 22, 14, 'active', NULL, 0),
(7, 2, 'army_camp', 1, 22, 30, 'active', NULL, 0),
(8, 2, 'cannon', 1, 15, 22, 'active', NULL, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `player_research`
--
-- Создание: Дек 10 2025 г., 17:13
--

DROP TABLE IF EXISTS `player_research`;
CREATE TABLE `player_research` (
  `id` int UNSIGNED NOT NULL,
  `user_id` int UNSIGNED NOT NULL,
  `tech_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ID технологии (напр. barbarian, healing_spell)',
  `level` int NOT NULL DEFAULT '1',
  `status` enum('active','researching') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `finish_time` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--
-- Создание: Дек 10 2025 г., 17:13
-- Последнее обновление: Дек 17 2025 г., 10:28
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int UNSIGNED NOT NULL,
  `login` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `xp` int NOT NULL DEFAULT '0',
  `trophies` int NOT NULL DEFAULT '0',
  `gold` int NOT NULL DEFAULT '1000',
  `elixir` int NOT NULL DEFAULT '1000',
  `dark_elixir` int NOT NULL DEFAULT '0',
  `gems` int NOT NULL DEFAULT '500',
  `last_update` int NOT NULL DEFAULT '0' COMMENT 'Unix timestamp последнего обновления ресурсов',
  `login_attempts` int NOT NULL DEFAULT '0',
  `last_attempt` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `login`, `password`, `xp`, `trophies`, `gold`, `elixir`, `dark_elixir`, `gems`, `last_update`, `login_attempts`, `last_attempt`, `created_at`) VALUES
(2, 'Admin', '$2y$12$Ea0RZLTJowq3V0JyKVTjUuT8F3vcHSBpthWoEXl0LQxCtBRoj0M72', 0, 0, 1018, 456, 0, 500, 1765967291, 0, '2025-12-02 20:04:46', '2025-12-01 13:49:08');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `clans`
--
ALTER TABLE `clans`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `clan_members`
--
ALTER TABLE `clan_members`
  ADD PRIMARY KEY (`id`),
  ADD KEY `clan_id` (`clan_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Индексы таблицы `player_army`
--
ALTER TABLE `player_army`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_unit` (`user_id`,`unit_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Индексы таблицы `player_buildings`
--
ALTER TABLE `player_buildings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Индексы таблицы `player_research`
--
ALTER TABLE `player_research`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_tech` (`user_id`,`tech_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `login` (`login`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `clans`
--
ALTER TABLE `clans`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `clan_members`
--
ALTER TABLE `clan_members`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `player_army`
--
ALTER TABLE `player_army`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `player_buildings`
--
ALTER TABLE `player_buildings`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `player_research`
--
ALTER TABLE `player_research`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `clan_members`
--
ALTER TABLE `clan_members`
  ADD CONSTRAINT `clan_members_ibfk_1` FOREIGN KEY (`clan_id`) REFERENCES `clans` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `clan_members_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `player_army`
--
ALTER TABLE `player_army`
  ADD CONSTRAINT `player_army_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `player_buildings`
--
ALTER TABLE `player_buildings`
  ADD CONSTRAINT `player_buildings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `player_research`
--
ALTER TABLE `player_research`
  ADD CONSTRAINT `player_research_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
